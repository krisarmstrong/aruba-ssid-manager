# Contributing to Aruba SSID Configurator

We welcome contributions!

1. Fork the repo
2. Create a branch (`git checkout -b feature/your-feature`)
3. Make your changes with tests and doc updates
4. Commit (`git commit -m "feat: description"`) and push
5. Open a pull request against `main`
